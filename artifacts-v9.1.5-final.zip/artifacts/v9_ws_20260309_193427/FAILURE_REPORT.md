# FAILURE_REPORT
COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: FAIL (fast_delivery_ok=False, eventual_delivery_ok=False)
SCENARIO2: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO3: FAIL (fast_delivery_ok=False, eventual_delivery_ok=False)
P95_MS: 1620.6

## Failures
- scenario1_eventual_delivery_failed:11.390s
- scenario3_eventual_delivery_failed:in=2.606s,out=12.692s

## Warnings
- transport_p95_above_target:1620.6ms
- scenario1_fast_delivery_slow:11.390s
- scenario3_fast_delivery_slow:in=2.606s,out=12.692s