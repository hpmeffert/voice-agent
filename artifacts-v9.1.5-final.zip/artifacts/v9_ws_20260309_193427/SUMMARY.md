COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: FAIL (fast_delivery_ok=False, eventual_delivery_ok=False)
SCENARIO2: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO3: FAIL (fast_delivery_ok=False, eventual_delivery_ok=False)
P95_MS: 1620.6
