# FAILURE_REPORT
COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
SCENARIO2: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO3: FAIL (fast_delivery_ok=False, eventual_delivery_ok=False)
P95_MS: 1619.5

## Failures
- scenario3_eventual_delivery_failed:in=1.099s,out=11.139s
- scenario4_missing_voice_customer_event

## Warnings
- transport_p95_above_target:1619.5ms
- scenario1_fast_delivery_slow:7.544s
- scenario3_fast_delivery_slow:in=1.099s,out=11.139s