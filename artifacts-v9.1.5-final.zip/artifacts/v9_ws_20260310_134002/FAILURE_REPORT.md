# FAILURE_REPORT
COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO2: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO3: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
P95_MS: 13447.3

## Failures
- scenario4_eventual_delivery_failed:21.165s

## Warnings
- transport_p95_above_target:13447.3ms
- scenario3_fast_delivery_slow:in=0.687s,out=10.361s
- scenario4_fast_delivery_slow:21.165s