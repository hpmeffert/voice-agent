# FAILURE_REPORT
COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO2: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO3: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
P95_MS: 12193.6

## Failures
- scenario4_eventual_delivery_failed:20.462s

## Warnings
- transport_p95_above_target:12193.6ms
- scenario3_fast_delivery_slow:in=0.631s,out=8.990s
- scenario4_fast_delivery_slow:20.462s