# FAILURE_REPORT
COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
SCENARIO2: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
SCENARIO3: FAIL (fast_delivery_ok=False, eventual_delivery_ok=False)
P95_MS: 6034.3

## Failures
- scenario3_eventual_delivery_failed:in=5.574s,out=11.427s

## Warnings
- transport_p95_above_target:6034.3ms
- scenario1_fast_delivery_slow:6.057s
- scenario2_fast_delivery_slow:2.770s
- scenario3_fast_delivery_slow:in=5.574s,out=11.427s