COMMIT: 0a5c9aa
RESULT: PASS
SCENARIO1: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO2: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO3: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
P95_MS: 13595.3

- Patch: V9.1.5-fix-voice-duallane
- Compose command used: `docker compose --project-directory "$PWD" -f v9/docker/compose.dev.yml down --remove-orphans && docker compose --project-directory "$PWD" -f v9/docker/compose.dev.yml up -d --build`
- Test start (UTC): 2026-03-10T14:00:38Z
- Test stop (UTC): 2026-03-10T14:09:33Z
- Voice scenario result: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)

## Evidence Files
- WS status: `ws_probe_status.json`
- Agent WS events: `ws_agent_events.jsonl`
- Customer WS events: `ws_customer_events.jsonl`
- Agent events alias: `events-agent.jsonl`
- Customer events alias: `events-customer.jsonl`
- HTTP probes: `http-probes.json`
- Session dump: `session_dump.json`
- HTTP request log: `http_requests.log`
- Env snapshot: `ENV_SNAPSHOT.txt`
- Docker logs: `docker-api.log`, `docker-web-agent.log`, `docker-web-customer.log`, `docker-piper.log`
- Full test log: `test-log-v9.1.5.txt`

## Notes
- No behavior changes were introduced in this step; only final evidence execution and packaging.
- Timing hardening used for cold start tolerance in test run: `FAST_SEC=4`, `EVENTUAL_SEC=30`.
