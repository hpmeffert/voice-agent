# FAILURE_REPORT
COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
SCENARIO2: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO3: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
P95_MS: 10550.4

## Failures
- scenario4_eventual_delivery_failed:20.046s
- scenario4_lang_for_agent_not_en:de
- scenario4_tts_agent_lang_not_en:de

## Warnings
- transport_p95_above_target:10550.4ms
- scenario1_fast_delivery_slow:10.141s
- scenario3_fast_delivery_slow:in=9.151s,out=11.393s
- scenario4_fast_delivery_slow:20.046s