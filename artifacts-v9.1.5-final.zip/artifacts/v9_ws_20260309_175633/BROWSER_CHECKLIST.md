# 2-Minute Browser Checklist

1. Agent UI: set Agent language = EN, Incoming speak = ON, Customer speak on agent = OFF.
2. Customer UI: set Customer language = DE.
3. Send German customer text.
4. Verify agent gets Original+Translation without reload.
5. Send EN agent response.
6. Verify customer gets DE translation + DE TTS lane.
