COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
SCENARIO2: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
SCENARIO3: FAIL (customer input or routed answer missing)
P95_MS: 1636.6
