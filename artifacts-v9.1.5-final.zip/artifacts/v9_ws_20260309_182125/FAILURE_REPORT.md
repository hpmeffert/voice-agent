# FAILURE_REPORT
COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
SCENARIO2: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
SCENARIO3: FAIL (customer input or routed answer missing)
P95_MS: 1636.6

## Failures
- scenario3_missing_answer_event

## Warnings
- transport_p95_above_target:1636.6ms
- scenario1_fast_delivery_slow:5.990s
- scenario2_fast_delivery_slow:2.796s