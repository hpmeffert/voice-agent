# V9 Dual-Lane Smoke Summary (FAIL)

- generated_at_utc: 2026-03-09T16:27:49.545487+00:00
- session_id: test-session-1
- user_id: test-user-1
- agent_id: agenten-02

## Passed
- Case2 PASS
- Case3 PASS

## Failed
- Case1: delivery too slow (8.147s > 2.5s)
