COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: FAIL (missing customer->agent event)
SCENARIO2: FAIL (missing agent->customer message.created on customer ws)
SCENARIO3: FAIL (customer input or routed answer missing)
P95_MS: 0
