# FAILURE_REPORT
COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: FAIL (missing customer->agent event)
SCENARIO2: FAIL (missing agent->customer message.created on customer ws)
SCENARIO3: FAIL (customer input or routed answer missing)
P95_MS: 0

## Failures
- scenario2_missing_agent_to_customer_event
- scenario3_missing_customer_input_event
- scenario3_missing_answer_event
- scenario4_missing_voice_customer_event

## Warnings