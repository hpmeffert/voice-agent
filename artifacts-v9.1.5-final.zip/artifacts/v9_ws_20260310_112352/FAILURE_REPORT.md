# FAILURE_REPORT
COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO2: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO3: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
P95_MS: 11519.7

## Failures
- scenario4_eventual_delivery_failed:24.133s

## Warnings
- transport_p95_above_target:11519.7ms
- scenario3_fast_delivery_slow:in=0.712s,out=13.935s
- scenario4_fast_delivery_slow:24.133s