COMMIT: 0a5c9aa
RESULT: FAIL
SCENARIO1: PASS (fast_delivery_ok=False, eventual_delivery_ok=True)
SCENARIO2: PASS (fast_delivery_ok=True, eventual_delivery_ok=True)
SCENARIO3: FAIL (fast_delivery_ok=False, eventual_delivery_ok=False)
P95_MS: 11295.4
